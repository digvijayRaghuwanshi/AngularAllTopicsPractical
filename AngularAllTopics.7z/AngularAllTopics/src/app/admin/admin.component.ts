import { DOCUMENT } from '@angular/common';
import { Component, Inject, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from '../user.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  color="darkgrey";
  color1="red";
  visible=true;
  queryCountry="";
  queryTag="";
  queryTrending=10;
  hrev="https:google.com";
  changevalue="https:oracle.com";
  placeholderValue="Vanshi";
  constructor(private activated:ActivatedRoute ,private router: Router,private user:UserService,   @Inject(DOCUMENT) private _document: Document,) {
   
    this.activated.queryParams.subscribe(data => {
      this.queryCountry=data.country;
      this.queryTag=data.tag;
      this.queryTrending=data.trending;
    });
   }

  ngOnInit(): void {
  }
  focusmethod(){
    console.log("jay");
  }
  change(){
    this.visible=false;
    this.color="pink";
  }

  add(){
    this.user.sendData1=true;
    // this._document.defaultView.location.reload();
  }

}

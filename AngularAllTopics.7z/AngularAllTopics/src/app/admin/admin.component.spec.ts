import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { UserService } from '../user.service';
import { AdminComponent } from './admin.component';

describe('AdminComponent', () => {
  let component: AdminComponent;
  let fixture: ComponentFixture<AdminComponent>;
  let service: UserService;
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AdminComponent],
      imports: [RouterTestingModule.withRoutes([])],
      providers: [{UserService , useValue: {UserService}}]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should create method', () => {
    component.change();
    expect(component.visible).toBe(false);
    expect(component.color).toBe('pink');
  });

  it('should create method', () => {
    component.focusmethod();
    expect('jay').toBe('jay');
  });

  it('should create method', () => {
    component.add();
    var services = TestBed.get(UserService); // get your service
    expect(services.sendData1).toBe(true);
  });
});

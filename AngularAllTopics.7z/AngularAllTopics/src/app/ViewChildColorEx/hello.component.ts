import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';

@Component({
  selector: 'app-hello',
  templateUrl: './hello.component.html',
  styleUrls: ['./hello.component.css']
})
export class HelloComponent implements OnInit {
  // @ViewChild('box') box:ElementRef
  @ViewChild('box',{static:true}) box:ElementRef;
  constructor() { }

  ngOnInit(): void {
    console.log(this.box);
    this.box.nativeElement.style.backgroundColor="red";
  }

  ngAfterViewInit(){
    console.log(this.box);
  }

}

import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  constructor(private router:Router){}
  name = "angular";
  jay = "sd";
  get() {
    alert(this.name);
    console.log("sd");
  }

  send(){
    this.router.navigateByUrl("/hello/3");
    //this.router.navigate(['/Test']);
  }
}

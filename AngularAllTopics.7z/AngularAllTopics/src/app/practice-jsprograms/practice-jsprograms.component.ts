import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-practice-jsprograms',
  templateUrl: './practice-jsprograms.component.html',
  styleUrls: ['./practice-jsprograms.component.css']
})
export class PracticeJSprogramsComponent implements OnInit {
  program1: any;
  proprint: any;
  program2: any;
  proprint1: any;
  program3: any;
  proprint2: any;
  program4: any;
  proprint3: any;
  disable: boolean;
  disable1: boolean;
  disable2: boolean;
  disable3: boolean;
  disable4: boolean;
  float: number;
  no: any;
  a: any;
  b: any;
  numberOfDigits: any;
  number: any;
  constructor() { }

  ngOnInit(): void {

  }

  p1() {
    //PRIME NO PROGRAM
    this.proprint = prompt("Enter PrimeNO." + this.program1);
    if (this.proprint % 2 === 1) {
      this.disable = true;
      this.disable1 = false;
      console.log("Its prime No.")
    }
    else if (this.proprint == 2) {
      this.disable = true;
      this.disable1 = false;
      console.log("Its Prime No.");
    }
    else {
      this.disable1 = true;
      this.disable = false;
      console.log("Its Not Prime No.");
    }
  }

  p2() {
    // program that checks if the number is positive, negative or zero
    this.proprint1 = prompt("Enter PrimeNO." + this.program2);
    if (this.proprint1 > 0) {
      this.disable2 = true;
      this.disable3 = false;
      this.disable4 = false;
      console.log("Its Positive no.")
    }
    else if (this.proprint1 == 0) {
      this.disable2 = false;
      this.disable3 = true;
      this.disable4 = false;
      console.log("Its Zero");
    }
    else {
      this.disable2 = false;
      this.disable3 = false;
      this.disable4 = true;
      console.log("Its Negative No.");
    }
  }

  p3() {
    // program to find the factorial of a number
    this.proprint2 = 8;
    this.float = 1;
    for (this.no = 1; this.no <= this.proprint2; this.no++) {
      this.float = this.float * this.no;
    }
    console.log(this.float);
    // var a = 6;
    // var float = 1;
    // for (var i = 1; i <= a; i++) {
    //     float = float * i;
    // }
    // console.log(float);
  }
  string;
  p4() {
    // program to trim a string
     this.string = prompt("Enter a Text");

    const result = this.string.split(' ').join('');

    console.log(result);
  }

  p5() {
    // program to check if a number is a float or integer value
    this.proprint3 = 23;
    if (Number.isInteger(this.proprint3)) {
      console.log("It is");
    } else {
      console.log("It is not");
    }
  }

  p6() {
    // setTimeOut Program
    function set(x, y) {
      console.log(x);
      console.log(y);
    }
    setTimeout(set, 3000, "Hello", "John");
    console.log("Please wait 3 sec");
  }

  p7() {
    //Prime No. List
    this.a = "1";
    this.b = "100";
    for (this.a = 1; this.a <= this.b; this.a++) {
      if (this.a % 2 == 1 && this.a !== 1) {
        console.log(this.a);
      }
      else if (this.a == 2) {
        console.log(this.a);
      }
      else {

      }
    }
  }

  p8() {
    //Multiplication Table
    var number = 23;
    for (var i = 1; i <= 10; i++) {
      const result = i * number;
      console.log(result);
    }
  }

  p9() {
    //Program Fibonacci Series
    var number = 4;
    let n1 = 0, n2 = 1, nextTerm;
    console.log('Fibonacci Series:');
    for (let i = 1; i <= number; i++) {
      nextTerm = n1 + n2;
      n1 = n2;
      n2 = nextTerm;
      console.log(n1);
    }
  }

  p10() {
    //Program Armstrong No.
    this.number = "153";
    this.numberOfDigits = this.number.length;
    var sum = 0;

    for (var i = 0; i < this.numberOfDigits; i++) {
      sum = sum + Math.pow(this.number.charAt(i), this.numberOfDigits);
    }

    if (sum == this.number) {
      console.log("The entered number is an Armstrong number.");

    } else {
      console.log("The entered number is not an Armstrong number.");
    }
  }

  p11() {
    //style program
    var element = document.getElementById("changeDesign");
    element.innerHTML = "ChangeText";
    element.style.textAlign = "center";
    element.style.display = "block";
    element.style.color = "red";
    element.style.backgroundColor = "black";
    document.body.style.backgroundColor = "red";
    var ele = document.getElementById("change");
    ele.innerHTML = "HELLO DIGVIJAY";
  }
}

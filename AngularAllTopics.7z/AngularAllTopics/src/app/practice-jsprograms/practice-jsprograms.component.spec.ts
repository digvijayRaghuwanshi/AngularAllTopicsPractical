import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PracticeJSprogramsComponent } from './practice-jsprograms.component';

describe('PracticeJSprogramsComponent', () => {
  let component: PracticeJSprogramsComponent;
  let fixture: ComponentFixture<PracticeJSprogramsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PracticeJSprogramsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PracticeJSprogramsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should create p8()', () => {
    component.p8();
    expect(230).toEqual(230);
  });

  it('should create p10()', () => {
    component.p10();
    var number = "153";
    var numberOfDigits = number.length;
    var sum = 0;

    for (var i = 0; i < numberOfDigits; i++) {
      sum = sum + Math.pow(component.number.charAt(i), numberOfDigits);
    }

    if (sum == component.number) {
      console.log("The entered number is an Armstrong number.");

    } else {
      console.log("The entered number is not an Armstrong number.");
    }
    expect(component.number).toBe('153');
    expect("The entered number is an Armstrong number.").toEqual("The entered number is an Armstrong number.");
  });

  it('should create p9()', () => {
    component.p9();
    expect(24).toEqual(24);
  });

  // it('should create p4()', () => {
  //   component.p4();
  //   // let string:any;
  //   const result = component.string.split(' ').join('');
  //   expect(component.string).toBe(result);
  // });
  
});

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LearnCheckboxSelectionComponent } from './learn-checkbox-selection.component';

describe('LearnCheckboxSelectionComponent', () => {
  let component: LearnCheckboxSelectionComponent;
  let fixture: ComponentFixture<LearnCheckboxSelectionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LearnCheckboxSelectionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LearnCheckboxSelectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

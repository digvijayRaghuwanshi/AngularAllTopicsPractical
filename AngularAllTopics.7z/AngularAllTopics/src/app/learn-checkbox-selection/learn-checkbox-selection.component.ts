import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-learn-checkbox-selection',
  templateUrl: './learn-checkbox-selection.component.html',
  styleUrls: ['./learn-checkbox-selection.component.css']
})
export class LearnCheckboxSelectionComponent implements OnInit {
  expand=false;
  expanded=false;
  constructor() { }

  ngOnInit(): void {
  }
  fetchData = [{"title":"saurabh"},{"title":"aman"},{"title":"jessica"},{"title":"rosh"}];

  showCheckboxes() {
    var checkboxes = document.getElementById("checkboxes");
    if (!this.expanded) {
      checkboxes.style.display = "block";
      this.expanded = true;
    } else {
      checkboxes.style.display = "none";
      this.expanded = false;
    }
  }

  selectCheckbox(){
    var checkboxes = document.getElementById("checkboxes");
    //  this.expanded =! this.expanded;
     if (!this.expand) {
      checkboxes.style.display = "block";
      this.expand = true;
    } else {
    
      this.expand = false;
      checkboxes.style.display = "block";
    }
  }
}

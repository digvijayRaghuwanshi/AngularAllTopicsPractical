import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-make-website',
  templateUrl: './make-website.component.html',
  styleUrls: ['./make-website.component.css']
})
export class MakeWebsiteComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

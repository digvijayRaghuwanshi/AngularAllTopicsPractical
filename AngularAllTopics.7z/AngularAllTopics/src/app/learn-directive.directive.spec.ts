import { LearnDirectiveDirective } from './learn-directive.directive';

describe('LearnDirectiveDirective', () => {
  it('should create an instance', () => {
    // const directive = new LearnDirectiveDirective();
    // expect(directive).toBeTruthy();
  });
});

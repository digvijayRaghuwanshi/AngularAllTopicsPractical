import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { MyWebsiteComponent } from './my-website.component';

describe('MyWebsiteComponent', () => {
  let component: MyWebsiteComponent;
  let fixture: ComponentFixture<MyWebsiteComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [MyWebsiteComponent],
      imports: [RouterTestingModule.withRoutes([]), FormsModule],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MyWebsiteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();

    jasmine.clock().uninstall();
    jasmine.clock().install();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  // it('should create String', () => {
  //   component.add();
  //   component.name;
  //   // var result = component.name.replace(/\s/g,'');
  //   expect("").toEqual("");
  // });

  it('should create route and method', () => {
    component.search();
    expect((component.stringName = 'html5')).toEqual('html5');

    const router = TestBed.get(Router);
    const spy = spyOn(router, 'navigate');
    component.search();
    expect(spy).toHaveBeenCalledWith(['html5']);
  });

  it('should create route and method', () => {
    component.search();
    expect((component.stringName = 'html')).toEqual('html');
    const router = TestBed.get(Router);
    const spy = spyOn(router, 'navigate');
    component.search();
    expect(spy).toHaveBeenCalledWith(['html']);
  });

  it('should create route and method', () => {
    component.search();
    expect((component.stringName = 'bootstrap')).toEqual('bootstrap');
    const router = TestBed.get(Router);
    const spy = spyOn(router, 'navigate');
    component.search();
    expect(spy).toHaveBeenCalledWith(['bootstrap']);
  });

  it('should create route and method', () => {
    component.search();
    expect((component.stringName = 'css')).toEqual('css');
    const router = TestBed.get(Router);
    const spy = spyOn(router, 'navigate');
    component.search();
    expect(spy).toHaveBeenCalledWith(['css']);
  });

  it('should create route and method', () => {
    component.search();
    expect((component.stringName = 'angular10')).toEqual('angular10');
    const router = TestBed.get(Router);
    const spy = spyOn(router, 'navigate');
    component.search();
    expect(spy).toHaveBeenCalledWith(['angular10']);
  });

  it('should create route and method', () => {
    component.search();
    expect((component.stringName = 'JS')).toEqual('JS');

    const router = TestBed.get(Router);
    const spy = spyOn(router, 'navigate');
    component.search();
    expect(spy).toHaveBeenCalledWith(['JS']);
  });

  it('call alert msg', () => {
    component.search();
    let alertMsg1;
    setTimeout(() => {
      alertMsg1 = false;
    }, 2500);
    // expect(component.alertMsg=false).toBe(false);
    jasmine.clock().tick(2501);
    expect(alertMsg1).toBe(false);
    // expect(component.alertMsg=true).toBe(true);
  });
});

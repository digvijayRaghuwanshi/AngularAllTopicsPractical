import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-my-website',
  templateUrl: './my-website.component.html',
  styleUrls: ['./my-website.component.css']
})
export class MyWebsiteComponent implements OnInit {
name:any;
stringName:String;
alertMsg:boolean;
  constructor(private router:Router) { }

  ngOnInit(): void {
    
  }
  add(){
    this.name.replace(/\s/g,'');
    this.stringName = this.name.replace(/\s/g,'');
  }

  search(){
    if(this.stringName=="html" || this.stringName=="HTML"){
      this.router.navigate(['html']);
    }

    else if(this.stringName=="html5"){
      this.router.navigate(['html5']);
    }

    else if(this.stringName=="css"){
      this.router.navigate(['css']); 
    }

    else if(this.stringName=="bootstrap"){
      this.router.navigate(['bootstrap']);
    }

    else if(this.stringName=="JS"){
      this.router.navigate(['JS']);
    }

    else if(this.stringName=="angular10"){
      this.router.navigate(['angular10']);
    }

    else{
      this.alertMsg=true;
      setTimeout(() => {
        this.alertMsg=false;
      },2500);   
      // alert("wrong searching")
    }
  }
}

import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { ChildComponent } from './components/child/child.component';
import { ParentComponent } from './components/parent/parent.component';
import { AngularLifeCycleHooksComponent } from './components/angular-life-cycle-hooks/angular-life-cycle-hooks.component';
import { HttpComponent } from './components/http/http.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { ViewEncapsulationComponent } from './components/view-encapsulation/view-encapsulation.component';
import { ServiceComponentOneComponent } from './components/service-component-one/service-component-one.component';
import { ServiceComponentTwoComponent } from './components/service-component-two/service-component-two.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SubjectOneComponentComponent } from './components/subject-one-component/subject-one-component.component';
import { SubjectTwoComponentComponent } from './components/subject-two-component/subject-two-component.component';
import { LearnDirectiveDirective } from './learn-directive.directive';
import { appPipe } from './Pipe/appPipe';
import { LearnpipeComponent } from './components/learnpipe/learnpipe.component';
import { LearnModelDrivenFormComponent } from './components/learn-model-driven-form/learn-model-driven-form.component';
import { LearnTemplateDrivenFormComponent } from './components/learn-template-driven-form/learn-template-driven-form.component';
import { AdminComponent } from './admin/admin.component';
import { ActivateGuard } from './activate.guard';
import { UserService } from './user.service';
import { HomeComponent } from './home/home.component';
import { Approutes } from './Routing';
import { UidesignComponent } from './uidesign/uidesign.component';
import { LearnHtmlComponent } from './learn-html/learn-html.component';
import { MakeWebsiteComponent } from './make-website/make-website.component';
import { LearnCSSComponent } from './learn-css/learn-css.component';
import { LearnBootstrap4Component } from './learn-bootstrap4/learn-bootstrap4.component';
import { LearnCheckboxSelectionComponent } from './learn-checkbox-selection/learn-checkbox-selection.component';
import { LearnJavascriptComponent } from './learn-javascript/learn-javascript.component';
import { LearnHtml5Component } from './learn-html5/learn-html5.component';
import { LearnGridComponent } from './learn-grid/learn-grid.component';
import { LearnGridWebsiteComponent } from './learn-grid-website/learn-grid-website.component';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { MyWebsiteComponent } from './my-website/my-website.component';
import { LearnAngular10Component } from './learn-angular10/learn-angular10.component';
import { ErrorMsgComponent } from './error-msg/error-msg.component';
import { HashLocationStrategy, LocationStrategy } from '@angular/common';
import { LoggingInterceptor } from './logging.interceptor';
import { PracticeJSprogramsComponent } from './practice-jsprograms/practice-jsprograms.component';
import { NoAuthGuard } from './no-auth.guard';
import { HelloComponent } from './ViewChildColorEx/hello.component';
import { LearnEmptyFilterComponent } from './learn-empty-filter/learn-empty-filter.component';

const appRoutes: Routes = [
  { path: "", redirectTo: 'website', pathMatch: "full" },
  // {path: '', component:HomeComponent},
  {path: 'Home', component:HomeComponent,canActivate:[NoAuthGuard]},
  {
    path: 'hello/:id',
    component: HelloComponent,
    canActivate: [ NoAuthGuard ]
  },
  { path: "website", component: MyWebsiteComponent },
  {path: 'admin', component:AdminComponent ,canActivate:[ActivateGuard]},
  { path: "pipe", component: LearnpipeComponent },
  { path: "lifeCycleHook", component: AngularLifeCycleHooksComponent },
  { path: "service", component: ServiceComponentOneComponent },
  { path: "http", component: HttpComponent },
  { path: "subject", component: SubjectOneComponentComponent },
  { path: "view-Encapsulation", component: ViewEncapsulationComponent },
  { path: "templateForm", component: LearnTemplateDrivenFormComponent },
  { path: "modelForm", component: LearnModelDrivenFormComponent },
  { path: "parent", component: ParentComponent },
  { path: "html", component: LearnHtmlComponent },
  { path: "html5", component: LearnHtml5Component },
  { path: "css", component: LearnCSSComponent },
  { path: "bootstrap4", component: LearnBootstrap4Component },
  { path: "sds", component: LearnBootstrap4Component },
  { path: "JS", component: LearnJavascriptComponent },
  { path: "angular10", component: LearnAngular10Component },
  { path: "admin", component: AdminComponent },
  { path: '**', component: ErrorMsgComponent },
]

@NgModule({
  declarations: [
    AppComponent,
    ChildComponent,
    ParentComponent,
    AngularLifeCycleHooksComponent,
    HttpComponent,
    ViewEncapsulationComponent,
    ServiceComponentOneComponent,
    ServiceComponentTwoComponent,
    SubjectOneComponentComponent,
    SubjectTwoComponentComponent,
    LearnDirectiveDirective,
    appPipe,
    LearnpipeComponent,
    LearnModelDrivenFormComponent,
    LearnTemplateDrivenFormComponent,
    AdminComponent,
    HomeComponent,
    UidesignComponent,
    ErrorMsgComponent,
    LearnHtmlComponent,
    MakeWebsiteComponent,
    LearnCSSComponent,
    LearnBootstrap4Component,
    LearnCheckboxSelectionComponent,
    LearnJavascriptComponent,
    LearnHtml5Component,
    LearnGridComponent,
    LearnGridWebsiteComponent,
    MyWebsiteComponent,
    LearnAngular10Component,
    PracticeJSprogramsComponent,
    HelloComponent,
    LearnEmptyFilterComponent,

  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forRoot(appRoutes),
    // RouterModule.forRoot(Approutes),
    NgMultiSelectDropDownModule.forRoot(),
    HttpClientModule
  ],
  providers: [ActivateGuard, UserService,
    { provide: LocationStrategy, useClass: HashLocationStrategy }, 
    { provide: HTTP_INTERCEPTORS, useClass: LoggingInterceptor, multi: true
    }],//Routing Stratgies {provide:LocationStrategy,useClass:PathLocationStrategy}
  bootstrap: [AppComponent]
})
export class AppModule { }

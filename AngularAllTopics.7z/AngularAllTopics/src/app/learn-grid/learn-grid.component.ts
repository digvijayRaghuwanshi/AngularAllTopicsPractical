import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-learn-grid',
  templateUrl: './learn-grid.component.html',
  styleUrls: ['./learn-grid.component.css']
})
export class LearnGridComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

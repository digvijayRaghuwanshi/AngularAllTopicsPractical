import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LearnGridComponent } from './learn-grid.component';

describe('LearnGridComponent', () => {
  let component: LearnGridComponent;
  let fixture: ComponentFixture<LearnGridComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LearnGridComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LearnGridComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

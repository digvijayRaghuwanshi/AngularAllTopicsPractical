import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { from } from 'rxjs';
import { filter, toArray } from 'rxjs/operators';

@Component({
  selector: 'app-learn-empty-filter',
  templateUrl: './learn-empty-filter.component.html',
  styleUrls: ['./learn-empty-filter.component.css']
})
export class LearnEmptyFilterComponent implements OnInit {
  httpJson: any;
  httpObject: any;
  filterData;
  display: any = [];
  oldValue;
  form = new FormGroup({
    myElement: new FormControl(),
  });
  adminFilterList = [
    { key: 'Name', value: 'Empty Name' },
    { key: 'Password', value: 'Empty Password' },
    { key: 'birthdate', value: 'Empty birth date' },
  ];
  constructor(private http: HttpClient) { }

  ngOnInit(): void {
    this.http.get(`../../assets/data/data.json`).subscribe(
      (data: any[]) => {
        this.display = data;
        console.log(data);

        this.httpJson = JSON.stringify(this.display);
        console.log("String json object :", this.httpJson);
        console.log("Type :", typeof this.httpJson);

        // ConvertjSON to an object
        this.httpObject = JSON.parse(this.httpJson);
        console.log("JSON object -", this.httpObject);
        this.oldValue = this.form.value.myElement;
        const source = from(data)
       this.form.get('myElement').valueChanges.subscribe((a) => {
         if (a == "Name") {
           source.pipe(
             filter(member => member.name == "" ), toArray()).subscribe(res => this.display = res);
           // this.form
           //   .get('myElement')
           //   .setValue(this.oldValue, { emitEvent: false });
         } else {
           source.pipe(
             filter(member => member.Password == "" ), toArray()).subscribe(res => this.display = res);
          //  this.oldValue = a;
         }
       });
      })
      
  }

  changeData() {
    this.http.get(`../../assets/data/data.json`).subscribe(
      (data: any[]) => {
        this.display = data;
        console.log(data);

        this.httpJson = JSON.stringify(this.display);
        console.log("String json object :", this.httpJson);
        console.log("Type :", typeof this.httpJson);

        // ConvertjSON to an object
        this.httpObject = JSON.parse(this.httpJson);
        console.log("JSON object -", this.httpObject);
        const source = from(this.httpObject=data)
        source.pipe(
          filter(member => member.name == "john"), toArray()).subscribe(res => this.display = res);
      })
  }

}

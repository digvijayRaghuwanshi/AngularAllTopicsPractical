import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { AngularLifeCycleHooksComponent } from './angular-life-cycle-hooks.component';

describe('AngularLifeCycleHooksComponent', () => {
  let component: AngularLifeCycleHooksComponent;
  let fixture: ComponentFixture<AngularLifeCycleHooksComponent>;
  let element;
  var originalTimeout;
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AngularLifeCycleHooksComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AngularLifeCycleHooksComponent);
    component = fixture.componentInstance;
    element = fixture.nativeElement;
    fixture.detectChanges();
    originalTimeout = jasmine.DEFAULT_TIMEOUT_INTERVAL;
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 1000000;
  });

  afterEach(function() {
    jasmine.DEFAULT_TIMEOUT_INTERVAL = originalTimeout;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should be called console', () => {
    expect(component.onChange()).toBe();
  });

  it('Check ngOnInit', () => {
    expect(component.ngOnInit()).toBe();
  });

  it('Check ngOnChanges', () => {
    expect(component.ngOnChanges(null)).toBe();
  });

  it('should be called console in HTML', () => {
    fixture.detectChanges();
    
    const button = fixture.debugElement.query(By.css('#edit'));
    button.triggerEventHandler('click', null);
    expect(component.onChange()).toBe();
  });

  it('should render `Hello Spiderman!` (async)', async(() => {
    //trigger change detection
    fixture.detectChanges();
    fixture.whenStable().then(() => { 
      expect(element.querySelector('h1').innerText).toBe('Hello');
    });
  }));
});

import { AfterContentChecked, AfterContentInit, AfterViewChecked, AfterViewInit, Component, DoCheck, OnChanges, OnDestroy, OnInit, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-angular-life-cycle-hooks',
  templateUrl: './angular-life-cycle-hooks.component.html',
  styleUrls: ['./angular-life-cycle-hooks.component.css']
})
export class AngularLifeCycleHooksComponent implements OnInit, DoCheck, OnChanges, AfterContentInit, AfterContentChecked,AfterViewInit,AfterViewChecked,OnDestroy {

  constructor() {
    console.log("ConstructorCalled");
  }

  ngOnChanges(element: SimpleChanges) {
    console.log("ngOnChangesCalled");
    console.log(element);
  }
  ngOnInit(): void {
    console.log("ngOnInitCalled");
  }
  ngDoCheck() {
    console.log("ngDoCheckCalled")
  }
  ngAfterContentInit() {
    console.log("ngAfterContentInitCalled");
  }
  ngAfterContentChecked() {
    console.log("ngAfterContentCheckedCalled");
  }
  ngAfterViewInit(){
    console.log("ngAfterViewInitCalled");
  }
  ngAfterViewChecked(){
    console.log("ngAfterViewCheckedCalled");
  }
  ngOnDestroy(){
    console.log("ngOnDestroyCalled");
  }
  onChange(){
    console.log("change");
  }
  add(){
    
  }
}

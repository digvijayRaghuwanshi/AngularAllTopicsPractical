import { HttpClient, HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { LearnServiceService } from 'src/app/learn-service.service';
import { HttpComponent } from './http.component';

describe('HttpComponent', () => {
  let component: HttpComponent;
  let fixture: ComponentFixture<HttpComponent>;
  let service: LearnServiceService;
  let mockHttpClient;
  let httpClient: HttpClient;
  // let httpClient1: HttpClient;
  let testUrl = `https://my-json-server.typicode.com/techsithgit/json-faker-directory/profiles/` + 2;
  
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HttpComponent ],
      imports:[HttpClientModule],
      providers: [{LearnServiceService, useValue: {LearnServiceService}}]
    })
    .compileComponents();
    httpClient = TestBed.get(HttpClient);
    // httpClient1 = TestBed.get(HttpClient);
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HttpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    service = new LearnServiceService(mockHttpClient);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('Check Array', () => {
    let display = [];
    expect(component.display).toEqual(display);
  });

  
  it('check http httpdelete',()=>{
    component.httpDelete();
     // Make an HTTP GET request
     httpClient.delete(testUrl).subscribe((data) =>
     // When observable resolves, result should match test data
     expect(data).toEqual(data)
   );
   expect(component.display).toEqual(component.display);
  })

  // it('check http httppost',()=>{
  //   component.httpFind();
  //    // Make an HTTP GET request
  //    httpClient1.get(testUrl).subscribe((data) =>
  //    // When observable resolves, result should match test data
  //    expect(data).toBe(data)
  //  );
  //  expect(component.display).toEqual(component.display);
  // })

 
});

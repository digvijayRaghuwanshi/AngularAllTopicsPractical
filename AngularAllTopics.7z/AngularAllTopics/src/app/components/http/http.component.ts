import { Component, OnDestroy, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { LearnServiceService } from 'src/app/learn-service.service';
import { from } from 'rxjs';
import { filter, toArray } from 'rxjs/operators';
@Component({
  selector: 'app-http',
  templateUrl: './http.component.html',
  styleUrls: ['./http.component.css'],
})
export class HttpComponent implements OnInit {
  display: any = [];
  displayName="";
  dataArr = [
    {
      id: 1,
      name: 'john',
      age: 21,
      gender: 'Male',
    },
    {
      id: 2,
      name: 'Digvijay',
      age: 31,
      gender: 'Male',
    },
    {
      id: 3,
      name: 'true',
      age: 41,
      gender: 'Male',
    },
    {
      id: 4,
      name: 'true',
      age: 21,
      gender: 'FeMale',
    },
    {
      id: 5,
      name: 'Digiraja',
      age: 31,
      gender: 'FeMale',
    },
    {
      id: 6,
      name: 'jOhny',
      age: 41,
      gender: 'Male',
    },
  ];
  constructor(private http: HttpClient, private learn: LearnServiceService) {}
  data;
  dataArrName: string;
  dataName: string;
  ngOnInit(): void {
    const source = from(this.dataArr);
    source
      .pipe(
        filter((member) => member.name.length > 2), //compare Length
        toArray()
      )
      .subscribe((res) => {
        console.log(res);
        this.data = res;
      });
    source
      .pipe(
        //compare Length
        toArray()
      )
      .subscribe((res) => {
        console.log(res);
        this.data = res;
      });
  }

  add() {
    const source = from(this.dataArr);
    source
      .pipe(
        filter((member) => member.gender == this.dataName), //compare Gender
        toArray()
      )
      .subscribe((res) => {
        console.log(res);
        this.data = res;
      });
  }

  addData() {
    const source = from(this.dataArr);
    source
      .pipe(
        filter((member) => member.name == this.dataArrName), //compare Length
        toArray()
      )
      .subscribe((res) => {
        console.log(res);
        this.data = res;
      });
  }

  httpGet() {
    this.learn.product().subscribe((product) => {
      this.display = product;
      console.log(product);
    });

    // this.http.get(`https://my-json-server.typicode.com/techsithgit/json-faker-directory/profiles/`).subscribe(
    //   (data: any[]) => {
    //     this.display = data;
    //     console.log(data);
    //   }
    // )
  }

  httpPost() {
    // this.learn.Postproduct().subscribe(
    //   product=>{
    //   this.display=product;
    // })
    this.http
      .post(
        `https://my-json-server.typicode.com/techsithgit/json-faker-directory/profiles/`,
        { name: 'mark', id: '32', }
      )
      .subscribe((data: any[]) => {
        this.display = data;
        console.log(data);
      });
  }

  httpPut() {
    const headers = { name: 'john', 'My-Custom-Header': 'foobar' };
    const body = { name: 'Angular PUT Request Example' };
    this.http
      .post(
        `https://my-json-server.typicode.com/techsithgit/json-faker-directory/profiles/`,
        body,
        { headers }
      )
      .subscribe((data: any[]) => {
        this.display = data;
        console.log(data);
      });
  }

  httpDelete() {
    this.http
      .delete(
        `https://my-json-server.typicode.com/techsithgit/json-faker-directory/profiles/` +
          2
      )
      .subscribe((data) => {
        this.display = data;
      });
  }

  httpFind() {
    this.http
      .get(
        `https://my-json-server.typicode.com/techsithgit/json-faker-directory/profiles/` +
          2
      )
      .subscribe((data) => {
        this.display = data;
      });
  }

  getParamId() {
    this.learn.getContactId().subscribe((product) => {
      this.display = product;
      console.log(product);
    });
  }
  sendData(){
    console.log(this.displayName)
  }
}

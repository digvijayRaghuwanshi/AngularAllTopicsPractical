import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { LearnServiceService } from 'src/app/learn-service.service';
import { ServiceComponentTwoComponent } from '../service-component-two/service-component-two.component';

@Component({
  selector: 'app-service-component-one',
  templateUrl: './service-component-one.component.html',
  styleUrls: ['./service-component-one.component.css']
})
export class ServiceComponentOneComponent implements OnInit {
  @ViewChild(ServiceComponentTwoComponent) Two:ServiceComponentTwoComponent


  dataDisplay={}
  namedata:String;
  constructor(private learn: LearnServiceService) { }

  ngOnInit(): void {

    this.learn.product().subscribe(
      product=>{
        this.dataDisplay=product;
      }
    )
  }
  one(){
    this.learn.add();
  }

  callTwo(){
    this.Two.Call();
  }
}

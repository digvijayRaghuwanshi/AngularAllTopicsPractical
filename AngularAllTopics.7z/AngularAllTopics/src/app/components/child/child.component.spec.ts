import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';

import { ChildComponent } from './child.component';

describe('ChildComponent', () => {
  let component: ChildComponent;
  let fixture: ComponentFixture<ChildComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ChildComponent],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ChildComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should check true or false', () => {
    expect(component.disable).toBe(true);
  });

  it('should check msg', () => {
    expect(component.outputString).toBe('Hi');
  });

  it('check output decorator', () => {
    component.outputString = 'Hi';
    component.myOutput.subscribe((response) => {
      expect(response).toEqual('Hi');
    });
    component.send();
  });

  it('check input decorator', () => {
    let myDataName=component.myName = '';
    expect(myDataName).toBe("");
    component.ngOnInit();
  });

  it('check send method', () => {
    let DisableN=component.disable=false;
    component.send();
    expect(component.disable).toBe(DisableN=!DisableN);
  });

  it('should be called console in HTML', () => {
    fixture.detectChanges();
    const button = fixture.debugElement.query(By.css('#data'));
    button.triggerEventHandler('click', null);
    expect(component.send()).toBe();
  });

  it('should be called ngIf', () => {
    fixture.detectChanges();
    const button = fixture.debugElement.query(By.css('.clickDisable'));
    expect(component.disable).toBe(true);
  });
});

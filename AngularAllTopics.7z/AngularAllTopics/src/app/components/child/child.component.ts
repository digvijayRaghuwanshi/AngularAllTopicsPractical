import { Component, OnInit, Input, SimpleChange, SimpleChanges, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {
  @Input() myName: string;
  @Output() myOutput: EventEmitter<String> = new EventEmitter();
  outputString="Hi";
  // private myNumber: number
  // constructor() { }
  // @Input()
  // set myNewNumber(number: number) {
  //   this.myNumber = number;
  // }
  // get myNewNumber() {
  //   return this.myNumber;
  // }
  disable=true;
  ngOnChanges(changes: SimpleChanges) {

    // const newNumberChange: SimpleChange = changes.myNewNumber;

    // console.log("Previous Value - ng on changes", newNumberChange.previousValue);
    // console.log("Current Value - ng on changes", newNumberChange.currentValue);
    // this.myNewNumber = newNumberChange.currentValue;
  }
  send() {
    console.log("this is child");
    this.myOutput.emit(this.outputString);
    this.disable=!this.disable;
    console.log(this.myOutput);
  }
// hidedata(){
// this.disable=!this.disable;
// }
  ngOnInit() {
    console.log(this.myName);
    // console.log("ngOnInit value", this.myNewNumber);
  }

}

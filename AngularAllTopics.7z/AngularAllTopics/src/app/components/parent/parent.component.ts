import { Component, OnInit, ViewChild, DoCheck, OnChanges, SimpleChange, SimpleChanges, AfterContentInit, AfterContentChecked, AfterViewInit, AfterViewChecked, OnDestroy } from '@angular/core';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.css']
})
export class ParentComponent implements OnInit, OnChanges {
  name = "this is Digvijay";
 
  // constructor() {
  //   console.log("ConstructorCalled");
  // }

  ngOnChanges(element: SimpleChanges) {
    console.log("ngOnChangesCalled");
    console.log(element);
  }
  ngOnInit(): void {
    console.log("ngOnInitCalled");
  }
  getdata(value) {
    console.log(value);
  }

  // Data=["a","b","c","d"];
  // deleteComponent(){
  //   this.Data.push("f");
  // }
  // private number: number = 12345;

  // get counter() {
  //   return this.number;
  // }

  // set counter(value) {
  //   this.number = value;
  // }

  // increament() {
  //   this.number++
  // }

  // decreament() {
  //   this.number--
  // }
  // change() {
  //   alert("hi");
  // }
}

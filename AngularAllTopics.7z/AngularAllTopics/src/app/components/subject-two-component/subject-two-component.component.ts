import { Component, OnInit } from '@angular/core';
import { LearnServiceService } from 'src/app/learn-service.service';

@Component({
  selector: 'app-subject-two-component',
  templateUrl: './subject-two-component.component.html',
  styleUrls: ['./subject-two-component.component.css']
})
export class SubjectTwoComponentComponent implements OnInit {
  namedata:String;
  constructor(private learn: LearnServiceService) { }

  ngOnInit(): void {
    this.learn.stringSubject.subscribe(
      (name)=>{
        this.namedata= name;
      }
    )
  }
}

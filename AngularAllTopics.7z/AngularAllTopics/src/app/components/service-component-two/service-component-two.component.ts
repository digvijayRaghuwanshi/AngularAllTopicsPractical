import { Component, OnInit } from '@angular/core';
import { LearnServiceService } from 'src/app/learn-service.service';

@Component({
  selector: 'app-service-component-two',
  templateUrl: './service-component-two.component.html',
  styleUrls: ['./service-component-two.component.css']
})
export class ServiceComponentTwoComponent implements OnInit {

  constructor(private learn: LearnServiceService) { }
  Datas = {};

  ngOnInit(): void {
    this.Datas = this.learn.Data;
  }

  Two() {
    this.learn.add();
  }

  Call() {
    alert("hi");
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-learnpipe',
  templateUrl: './learnpipe.component.html',
  styleUrls: ['./learnpipe.component.css']
})
export class LearnpipeComponent implements OnInit {
  value = "this is digvIjaY";
  reversevalue="digvijay";
  data = new Date();
  a: number = 1259;
  constructor() { }
  name = [
    "name",
    "Diggsds",
    "idsdsddsDigvijat",
    "this is digvIjaY"
  ]
  ngOnInit(): void {
  }

}

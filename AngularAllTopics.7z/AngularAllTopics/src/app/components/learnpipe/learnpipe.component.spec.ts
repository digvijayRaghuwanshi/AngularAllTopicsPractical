import { ComponentFixture, TestBed } from '@angular/core/testing';
import { appPipe } from 'src/app/Pipe/appPipe';

import { LearnpipeComponent } from './learnpipe.component';

describe('LearnpipeComponent', () => {
  let component: LearnpipeComponent;
  let fixture: ComponentFixture<LearnpipeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LearnpipeComponent,appPipe ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LearnpipeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

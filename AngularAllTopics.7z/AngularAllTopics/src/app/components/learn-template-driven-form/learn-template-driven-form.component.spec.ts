import { HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';

import { LearnTemplateDrivenFormComponent } from './learn-template-driven-form.component';

describe('LearnTemplateDrivenFormComponent', () => {
  let component: LearnTemplateDrivenFormComponent;
  let fixture: ComponentFixture<LearnTemplateDrivenFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [LearnTemplateDrivenFormComponent],
      imports: [HttpClientModule, FormsModule],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LearnTemplateDrivenFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should be login', () => {
    let data = component.userlogin.value;
    component.onData(data);
    expect(data.emailId).toBeFalsy();
    expect(data.passwd).toBeFalsy();
  });
});

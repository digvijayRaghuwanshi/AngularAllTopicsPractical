import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-learn-template-driven-form',
  templateUrl: './learn-template-driven-form.component.html',
  styleUrls: ['./learn-template-driven-form.component.css']
})
export class LearnTemplateDrivenFormComponent implements OnInit {
  @ViewChild('userlogin',{static:true}) userlogin:NgForm;
  user:any;
  
  // useremail:any;
  constructor() { 

  }

  ngOnInit(): void {
  // setInterval(()=>{this.onData},2000);

  }
  
  onData(data) {
    // console.log(data);
    // this.user=data.emailId;
    // this.user=data.passwd;
    // console.log("Data:-" + data.emailId);
    // console.log("Data:-" + data.passwd);
    // this.user= this.userlogin.value.emailId;
    // this.user= this.userlogin.value.passwd;
  }
}

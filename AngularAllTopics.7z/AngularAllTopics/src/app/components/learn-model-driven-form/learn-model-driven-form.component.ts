import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
@Component({
   selector: 'app-learn-model-driven-form',
   templateUrl: './learn-model-driven-form.component.html',
   styleUrls: ['./learn-model-driven-form.component.css']
})
export class LearnModelDrivenFormComponent implements OnInit {
   formdata: FormGroup;
   emailid: any;
   user: any;
   valueTraked:String;
   constructor(private formBuilder: FormBuilder) {
      //   this.formdata=formBuilder.group({
      //    emailid: new FormControl(),
      //    passwd: new FormControl()
      //   });

   }

   ngOnInit() {
      this.formdata = this.formBuilder.group({
         
      // emailid: ['', [Validators.required, Validators.email]],
         // passwd: ['', Validators.required]
      });
      console.log(this.formdata);
      // this.formdata.setValue({
      //    user:'Digvijay',
      //    emailid:'digvijay@gmail.com',
      //    passwd:'',
      // });
      // this.formdata.get('user').valueChanges.subscribe(data=>{ //changes only one field
      //    console.log(data);
      //    this.valueTraked=data;
      // });

      // this.formdata.valueChanges.subscribe(data=>{ // Changes in entire field of form
      //    console.log(data);
      //    this.valueTraked=data;
      // });
      
      // this.formdata.patchValue({
      //    user: 'Digvijay',
      //    emailid: 'digvijay@gmail.com',
      //    passwd: '',
      // });
      //  this.formdata = new FormGroup({
      //     emailid: new FormControl("", Validators.compose([
      //        Validators.required,
      //        Validators.pattern("[^ @]*@[^ @]")
      //     ])),
      //     passwd: new FormControl("", this.passwordvalidation)
      //  });
   }
   //  passwordvalidation(formcontrol) {
   //     if (formcontrol.value.length < 5) {
   //        return {"passwd" : true};
   //     }
   //  }
   onClickSubmit(data) { 
      this.user = data.user,
      this.emailid = data.emailid; 
   }
 
   resetForm() {
      this.formdata.reset();
   }
}



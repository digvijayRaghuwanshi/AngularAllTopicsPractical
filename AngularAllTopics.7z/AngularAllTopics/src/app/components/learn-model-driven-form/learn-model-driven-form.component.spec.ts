import { HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { LearnModelDrivenFormComponent } from './learn-model-driven-form.component';

fdescribe('LearnModelDrivenFormComponent', () => {
  let component: LearnModelDrivenFormComponent;
  let fixture: ComponentFixture<LearnModelDrivenFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [LearnModelDrivenFormComponent],
      imports: [HttpClientModule, ReactiveFormsModule],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LearnModelDrivenFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should be show in login', () => {
    expect(component.formdata.value).toEqual({
      user: '',
      emailid: '',
      passwd: '',
    });
  });

  it('should be reset', () => {
    component.resetForm();
    expect(component.formdata.reset()).toBe();
  });

  it('should be login', () => {
    let data = component.formdata.value;
    component.onClickSubmit(data);
    expect(data.user).toBe('');
    expect(data.emailid).toBe('');
  });

  it("check Validation",()=>{
    fixture.detectChanges();
    fixture.whenStable().then(()=>{
      const userCheck: HTMLInputElement=fixture.debugElement.nativeElement.querySelector('#userCheck');
      userCheck.value='';
      userCheck.dispatchEvent(new Event('input'));
      const emailElement: HTMLInputElement=fixture.debugElement.nativeElement.querySelector('#emailElement');
      emailElement.value='';
      emailElement.dispatchEvent(new Event('input'));
      fixture.whenStable().then(()=>{
        const userValidator:HTMLParagraphElement=fixture.debugElement.nativeElement.querySelector('#userRequired');
        expect(userValidator.children.length).toEqual(1);
        expect(userValidator.innerHTML).toEqual("Enter Username");

        const emailValidator:HTMLParagraphElement=fixture.debugElement.nativeElement.querySelector('#emailRequired');
        expect(emailValidator).not.toBeNull();
        expect(emailValidator.innerHTML).toEqual("Enter Emailid");

        const loginButton:HTMLButtonElement=fixture.debugElement.nativeElement.querySelector('#loginButton');
        expect(loginButton.disabled).toBeTruthy();
        // expect(emailValidator.innerHTML).toEqual("Enter Emailid");
      })
    })
  })
});

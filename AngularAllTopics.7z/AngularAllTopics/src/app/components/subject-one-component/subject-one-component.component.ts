import { Component, OnInit } from '@angular/core';
import { LearnServiceService } from 'src/app/learn-service.service';

@Component({
  selector: 'app-subject-one-component',
  templateUrl: './subject-one-component.component.html',
  styleUrls: ['./subject-one-component.component.css']
})
export class SubjectOneComponentComponent implements OnInit {
  myText:String;
  constructor(private learn: LearnServiceService) { }

  ngOnInit(): void {
  }
  add(){
    this.learn.passValue(this.myText);
  }

}

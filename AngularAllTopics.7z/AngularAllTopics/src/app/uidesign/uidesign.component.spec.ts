import { HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';

import { UidesignComponent } from './uidesign.component';

describe('UidesignComponent', () => {
  let component: UidesignComponent;
  let fixture: ComponentFixture<UidesignComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UidesignComponent ],
      imports:[HttpClientModule,FormsModule]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UidesignComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

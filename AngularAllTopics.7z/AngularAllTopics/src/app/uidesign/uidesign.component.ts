import { HttpClient } from '@angular/common/http';
import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { UserserviceService } from '../userservice.service';

@Component({
  selector: 'app-uidesign',
  templateUrl: './uidesign.component.html',
  styleUrls: ['./uidesign.component.css']
})
export class UidesignComponent implements OnInit {
  @Input() myName: String;
  @Input() myName1: String;
  @Output() myOutput: EventEmitter<String> = new EventEmitter();
  outputString = "Hi";
  disable = false;
  display: any = [];
  displays = true;
  displaydatashowandhide=true;
  class1="one";
  class2="two";
  loader:boolean;
  name:String;
  Jsondata:any;

  stringJson: any;
  stringObject: any;
  httpJson: any;
  httpObject: any;
  courseList = [
    {
      courseid: "1",
      coursename: "Java programming",
      author: "Franc"
    },
    {
      courseid: "2",
      coursename: "Learn Typescript programming",
      author: "John"
    }
  ];
  constructor(private user: UserserviceService, private http: HttpClient) {
    
  }
  LocalName:string;
  ngOnInit(): void {
   
    this.myOutput.emit(this.outputString);
    console.log(this.myOutput);
    this.http.get(`../../assets/data/data.json`).subscribe(
      (data: any[]) => {
        this.display = data;
        console.log(data);

        this.httpJson = JSON.stringify(this.display);
        console.log("String json object :", this.httpJson);
        console.log("Type :", typeof this.httpJson);
     
        // ConvertjSON to an object
        this.httpObject = JSON.parse(this.httpJson);
        console.log("JSON object -", this.httpObject);
      }
    )
    this.loader=true;
   setTimeout(() => {
     this.loader=false;
    this.name="hi Digvijay";
   },3000)


   this.stringJson = JSON.stringify(this.courseList);
   console.log("String json object :", this.stringJson);
   console.log("Type :", typeof this.stringJson);

   // ConvertjSON to an object
   this.stringObject = JSON.parse(this.stringJson);
   console.log("JSON object -", this.stringObject);
  }

  person = [
    {
      name: "Digvijay",
      surname: "Raghuwanshi"
    },
    {
      name: "ngStyle is changing div element",
      surname: "Raghuwanshi1"
    },
    {
      name: "ngStyle is changing d",
      surname: "Raghuwanshi2"
    }
  ]

  getColor(surname) {
    switch (surname) {
      case 'Raghuwanshi':
        return 'green';
      case 'Raghuwanshi1':
        return 'blue';
      case 'Raghuwanshi2':
        return 'red';
    }
  }
  
  onData(userLogin) {
    this.user.onData(userLogin);
    this.disable = true;
    localStorage.setItem('name', "digvijay" );
    // localStorage.getItem('name');
    this.LocalName=localStorage.getItem('name');
  }
}

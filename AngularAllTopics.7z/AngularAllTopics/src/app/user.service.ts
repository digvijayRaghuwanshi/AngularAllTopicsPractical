import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  sendData=false;
  sendData1=false;
  constructor() { }
//   isAdminRights(){
//    this.sendData=  true;
// }
}

import { TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';

import { ActivateGuard } from './activate.guard';

describe('ActivateGuard', () => {
  let guard: ActivateGuard;

  beforeEach(() => {
    TestBed.configureTestingModule({imports: [RouterTestingModule.withRoutes([])],});
    guard = TestBed.inject(ActivateGuard);
  });

  it('should be created', () => {
    expect(guard).toBeTruthy();
  });
});

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LearnJavascriptComponent } from './learn-javascript.component';

describe('LearnJavascriptComponent', () => {
  let component: LearnJavascriptComponent;
  let fixture: ComponentFixture<LearnJavascriptComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LearnJavascriptComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LearnJavascriptComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

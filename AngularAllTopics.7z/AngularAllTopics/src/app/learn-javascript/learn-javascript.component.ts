import { Component, OnInit, ViewChild } from '@angular/core';
import { IDropdownSettings } from 'ng-multiselect-dropdown';
@Component({
  selector: 'app-learn-javascript',
  templateUrl: './learn-javascript.component.html',
  styleUrls: ['./learn-javascript.component.css']
})
export class LearnJavascriptComponent implements OnInit {
  // disable=false;
  cities = [];
  selectedItem = [];
  dropdownSettings: any = {};
  closeDropdownSelection=false;
  disabled=false;
  constructor() { 

  }

  ngOnInit(): void {   
  
    this.cities = ['Mumbai', 'New Delhi', 'Bangaluru', 'Pune', 'Navsari'];
            this.selectedItem = ['Pune'];
            this.dropdownSettings = {
                singleSelection: true,
                selectAllText: 'Select All',
                unSelectAllText: 'UnSelect All',
                allowSearchFilter: true,
                closeDropDownOnSelection: this.closeDropdownSelection
            };
    
  }
 
 

  onItemSelect(item: any) {
    console.log('onItemSelect', item);
}

toggleCloseDropdownSelection() {
    this.closeDropdownSelection = !this.closeDropdownSelection;
    this.dropdownSettings = Object.assign({}, this.dropdownSettings,{closeDropDownOnSelection: this.closeDropdownSelection});
}

  cars={
    carName:"ford",
    Marks:"32"
  }

  cars1=[
  {
    carName:"ford",
    selected:true
  },
  {
    carName:"Swift"
  }
]

add(){
  
  document.getElementById("checkbox").style.display="block";
}

  learnjs(){
    this.cars;
   
    var a="Hello";
    console.log(a.split('').reverse().join(''));   

  }  
  show:any;
  showCheckboxes() {
    this.cars1[0].selected=true;
    var checkboxes = document.getElementById("checkBoxes");

    if (this.show) {
        checkboxes.style.display = "block";
        this.show = false;
    } else {
        checkboxes.style.display = "none";
        this.show = true;
    }
}
}

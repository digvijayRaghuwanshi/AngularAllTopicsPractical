import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-learn-html',
  templateUrl: './learn-html.component.html',
  styleUrls: ['./learn-html.component.css']
})
export class LearnHtmlComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

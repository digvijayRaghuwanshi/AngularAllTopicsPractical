import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LearnBootstrap4Component } from './learn-bootstrap4.component';

describe('LearnBootstrap4Component', () => {
  let component: LearnBootstrap4Component;
  let fixture: ComponentFixture<LearnBootstrap4Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LearnBootstrap4Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LearnBootstrap4Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

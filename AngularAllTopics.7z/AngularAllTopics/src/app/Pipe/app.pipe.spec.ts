import { appPipe } from "./appPipe";

describe('appPipe',()=>{
    it('create an instance', () => {
        const pipe = new appPipe();
        expect(pipe).toBeTruthy();
      });

      it('create an instance reverse', () => {
        const pipe = new appPipe();
        expect(pipe.transform('hel')).toBe('leh');
      });

      it('create an instance lowercase', () => {
        const pipe = new appPipe();
        expect(pipe.transform('A')).toBe('a');
      });


})
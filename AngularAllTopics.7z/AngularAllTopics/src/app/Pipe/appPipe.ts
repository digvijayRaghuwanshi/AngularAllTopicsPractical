import {PipeTransform, Pipe} from '@angular/core';
@Pipe({
    name:'myPipe',
    pure: false
})
export class appPipe implements PipeTransform {
    
transform(reversevalue:String){
// return value.toUpperCase();
console.log(reversevalue.split("").reverse().join(''));
// console.log(value);
if(reversevalue.length>1){
return reversevalue.split("").reverse().join('');
}
else{
    return reversevalue.toLowerCase();
}
// if(value.length>8){
//     return value.substring(0,18).toLowerCase()+'...';  
// }
// else{
//     return value.toUpperCase();
// }

}
}
import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LearnAngular10Component } from './learn-angular10.component';

describe('LearnAngular10Component', () => {
  let component: LearnAngular10Component;
  let fixture: ComponentFixture<LearnAngular10Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LearnAngular10Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LearnAngular10Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

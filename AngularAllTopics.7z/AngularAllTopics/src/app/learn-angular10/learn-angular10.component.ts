import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-learn-angular10',
  templateUrl: './learn-angular10.component.html',
  styleUrls: ['./learn-angular10.component.css']
})
export class LearnAngular10Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

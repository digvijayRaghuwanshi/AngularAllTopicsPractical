import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-learn-css',
  templateUrl: './learn-css.component.html',
  styleUrls: ['./learn-css.component.css']
})
export class LearnCSSComponent implements OnInit {
  
  constructor() { }

  ngOnInit(): void {
  }
}

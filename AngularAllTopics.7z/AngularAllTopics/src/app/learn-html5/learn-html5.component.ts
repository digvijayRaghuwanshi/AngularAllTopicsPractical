import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-learn-html5',
  templateUrl: './learn-html5.component.html',
  styleUrls: ['./learn-html5.component.css']
})
export class LearnHtml5Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

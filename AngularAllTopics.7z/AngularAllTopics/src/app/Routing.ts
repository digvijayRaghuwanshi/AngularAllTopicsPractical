import {Routes} from '@angular/router';
import {AdminComponent} from './admin/admin.component';
import {HomeComponent} from './home/home.component';
import {ActivateGuard} from './activate.guard';
import { ErrorMsgComponent } from './error-msg/error-msg.component';

export const Approutes:Routes=
[
    {path: '', component:HomeComponent},
    {path: 'Home', component:HomeComponent},
    {path: '**', component:ErrorMsgComponent},
    {path: 'admin', component:AdminComponent ,canActivate:[ActivateGuard]},
    // {
    //     path: 'orders',
    //     loadChildren: () => import('./orders/orders.module').then(m => m.OrdersModule)
    // },
]
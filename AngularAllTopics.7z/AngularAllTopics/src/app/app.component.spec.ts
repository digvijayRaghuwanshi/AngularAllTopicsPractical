import { async, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { AppComponent } from './app.component';
import { RouterOutlet } from '@angular/router';


describe('AppComponent', () => {
  let fixture:any;
  let router:Router;
  let location: Location;
  let app:any;
  var originalTimeout;
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [
        AppComponent
      ],
      imports: [RouterTestingModule.withRoutes([])],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AppComponent);
    app = fixture.componentInstance;
    originalTimeout = jasmine.DEFAULT_TIMEOUT_INTERVAL;
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 1000000;
  });

  afterEach(function() {
    jasmine.DEFAULT_TIMEOUT_INTERVAL = originalTimeout;
  });

  it('should create the app', () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance;
    expect(app).toBeTruthy();
  });

  it(`should have as title 'angularPracticallyLearn'`, () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance;
    expect(app.name).toEqual('angular');
  });

  it(`should have as title 'sd'`, () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance;
    let name="angular";
    app.get();
    expect('sd').toEqual('sd');
    expect(window.alert(name)).toBe();
  });

  it(
    'should have a router outlet',
    async(() => {
      const element = fixture.debugElement.query(By.directive(RouterOutlet));
      expect(element).not.toBeNull();
    })
  );

  it('should redirect the user to `Test Component` component when Edit button is clicked', () => {
    const router = TestBed.get(Router);
    const spy = spyOn(router, 'navigateByUrl');
    fixture.detectChanges();
    // const button = fixture.debugElement.query(By.css('#edit'));
    // button.triggerEventHandler('click', null);
    app.send();
    expect(spy).toHaveBeenCalledWith('/hello/3');
  });

  // it('should render title', () => {
  //   const fixture = TestBed.createComponent(AppComponent);
  //   fixture.detectChanges();
  //   const compiled = fixture.nativeElement;
  //   expect(compiled.querySelector('.content span').textContent).toContain('angularPracticallyLearn app is running!');
  // });
});

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LearnGridWebsiteComponent } from './learn-grid-website.component';

describe('LearnGridWebsiteComponent', () => {
  let component: LearnGridWebsiteComponent;
  let fixture: ComponentFixture<LearnGridWebsiteComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LearnGridWebsiteComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LearnGridWebsiteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

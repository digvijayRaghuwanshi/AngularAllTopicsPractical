import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-learn-grid-website',
  templateUrl: './learn-grid-website.component.html',
  styleUrls: ['./learn-grid-website.component.css']
})
export class LearnGridWebsiteComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, Subject } from 'rxjs';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class LearnServiceService {
public stringSubject=new BehaviorSubject("");
  add() {
    alert("hi, I am Digvijay");
  }
  Data = [
    { name: "Digvijay", id: 1 }
  ]

  constructor(private http: HttpClient) { }
  // url = "https://my-json-server.typicode.com/techsithgit/json-faker-directory/profiles/";
  url="assets/data/data.json";
  product(): Observable<any> {
    let httpheaders=new HttpHeaders({
      "content-type":"application/json",
      "Authorization":"ABCTutorial",
      "timeOutSeconds":"3000"
    })

    httpheaders=httpheaders.set("abc-tutorial","110");
    let time = httpheaders.get("timeOutSeconds");
    if(time === '3000'){
      httpheaders=httpheaders.set("Authorization","");
    }
    return this.http.get(this.url,{headers:httpheaders});
  }

  
  Postproduct(): Observable<any>{
    return this.http.post(this.url,{name :"mark",id:42});
  }

  passValue(data){
    this.stringSubject.next(data);
  }

  getContactId(){
    const httpParams=new HttpParams({
      fromObject:{
        id:"1"
      }
    });
    return this.http.get(this.url,{params:httpParams});
  }

  HttpGet(){
    return this.http.get(this.url);
  }
}

import { HttpClient, HttpClientModule } from '@angular/common/http';
import { TestBed } from '@angular/core/testing';
import { of } from 'rxjs';

import { LearnServiceService } from './learn-service.service';
let httpClient: HttpClient;

const testUrl = "assets/data/data.json";
describe('LearnServiceService', () => {
  let service: LearnServiceService;
  let mockHttpClient;

  beforeEach(() => {
    service = new LearnServiceService(mockHttpClient);
    TestBed.configureTestingModule({ imports: [HttpClientModule] });
    service = TestBed.inject(LearnServiceService);
    httpClient = TestBed.get(HttpClient);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should be popup alert msg', () => {
    service.add();
    expect(window.alert('hi, I am Digvijay')).toBe();
  });

  it("HttpGet() call",()=>{
    service.HttpGet();
    httpClient.get(testUrl).subscribe((data) =>
    // When observable resolves, result should match test data
    expect(data).toEqual(data)
  );
    // expect(mockHttpService.get(mockResponse)).toBeFalsy();
  })

  it("Subj",()=>{
    let data:any;
    service.passValue(data);
    expect(service.stringSubject.next(data)).toEqual(data);
  })

  it("product() call",()=>{
    let mockResponse = "assets/data/data.json";
    const mockHttpService: any = jasmine.createSpyObj(['get', 'delete', 'post', 'patch']);
    service.product();
    expect(mockHttpService.get(mockResponse)).toBeFalsy();
  })

  it("Postproduct() call",()=>{
    let mockResponse = "assets/data/data.json";
    const mockHttpService: any = jasmine.createSpyObj(['get', 'delete', 'post', 'patch']);
    service.Postproduct();
    expect(mockHttpService.post(mockResponse)).toBeFalsy();
  })

  it("getContactId() call",()=>{
    let mockResponse = "assets/data/data.json";
    const mockHttpService: any = jasmine.createSpyObj(['get', 'delete', 'post', 'patch']);
    service.getContactId();
    expect(mockHttpService.get(mockResponse)).toBeFalsy();
  })

});
